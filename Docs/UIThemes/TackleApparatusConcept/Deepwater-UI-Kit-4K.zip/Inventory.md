# Sprite inventory

Reference layout: 3840 × 2160. Export pixels are not a claim of new native raster detail. `Source crop` is the original generated detail size. Frames marked sliced use the border metadata in Manifest.json.

| ID | Asset | Page | Export pixels | Source crop | Rendering |
|---|---|---|---|---|---|
| TA-013 | [rig-card-ivory](Exports/Common/rig-card-ivory.png) | common | 832 × 652 | 416 × 326 | 9-slice |
| TA-001 | [desk-background](Exports/Common/desk-background.png) | common | 3840 × 2160 | 1672 × 941 | Preserve aspect |
| TA-002 | [machine-housing](Exports/Common/machine-housing.png) | common | 3196 × 1612 | 1598 × 806 | Preserve aspect |
| TA-003 | [rig-cabinet](Exports/Common/rig-cabinet.png) | common | 1252 × 3270 | 626 × 1635 | Preserve aspect |
| TA-004 | [title-plaque](Exports/Common/title-plaque.png) | common | 1184 × 234 | 592 × 117 | 9-slice |
| TA-005 | [haul-plaque](Exports/Common/haul-plaque.png) | common | 848 × 322 | 424 × 161 | Preserve aspect |
| TA-006 | [message-strip](Exports/Common/message-strip.png) | common | 1206 × 164 | 603 × 82 | 9-slice |
| TA-007 | [button-primary](Exports/Common/button-primary.png) | common | 1098 × 324 | 549 × 162 | 9-slice |
| TA-008 | [button-secondary](Exports/Common/button-secondary.png) | common | 1042 × 320 | 521 × 160 | 9-slice |
| TA-009 | [readout-glass-wide](Exports/Common/readout-glass-wide.png) | common | 1104 × 326 | 552 × 163 | 9-slice |
| TA-010 | [keycap](Exports/Common/keycap.png) | common | 590 × 284 | 295 × 142 | 9-slice |
| TA-011 | [status-plaque](Exports/Common/status-plaque.png) | common | 916 × 264 | 458 × 132 | 9-slice |
| TA-012 | [control-console](Exports/Common/control-console.png) | common | 1476 × 396 | 738 × 198 | 9-slice |
| TA-014 | [rig-card-sage](Exports/Common/rig-card-sage.png) | common | 836 × 648 | 418 × 324 | 9-slice |
| TA-015 | [portrait-frame](Exports/Common/portrait-frame.png) | common | 1010 × 502 | 505 × 251 | 9-slice |
| TA-016 | [card-clip](Exports/Common/card-clip.png) | common | 426 × 264 | 213 × 132 | Preserve aspect |
| TA-017 | [rope-horizontal](Exports/Common/rope-horizontal.png) | common | 858 × 184 | 429 × 92 | Preserve aspect |
| TA-018 | [rope-vertical](Exports/Common/rope-vertical.png) | common | 120 × 448 | 60 × 224 | Preserve aspect |
| TA-019 | [portrait-sardine](Exports/Common/portrait-sardine.png) | common | 880 × 346 | 440 × 173 | Preserve aspect |
| TA-020 | [portrait-mackerel](Exports/Common/portrait-mackerel.png) | common | 1008 × 458 | 504 × 229 | Preserve aspect |
| TA-021 | [portrait-glass-minnow](Exports/Common/portrait-glass-minnow.png) | common | 674 × 306 | 337 × 153 | Preserve aspect |
| TA-022 | [portrait-garfish](Exports/Common/portrait-garfish.png) | common | 1280 × 246 | 640 × 123 | Preserve aspect |
| TA-023 | [cursor-garfish-right](Exports/Common/cursor-garfish-right.png) | common | 1072 × 212 | 536 × 106 | Preserve aspect |
| TA-024 | [tag-schooling](Exports/Common/tag-schooling.png) | common | 1002 × 438 | 501 × 219 | Preserve aspect |
| TA-033 | [lamp-on](Exports/Common/lamp-on.png) | common | 554 × 560 | 277 × 280 | Preserve aspect |
| TA-034 | [lamp-off](Exports/Common/lamp-off.png) | common | 552 × 560 | 276 × 280 | Preserve aspect |
| TA-036 | [readout-glass-small](Exports/Common/readout-glass-small.png) | common | 1016 × 362 | 508 × 181 | 9-slice |
| TA-025 | [reel-drum](Exports/Discover/reel-drum.png) | discover | 824 × 980 | 412 × 490 | Preserve aspect |
| TA-026 | [reel-bezel](Exports/Discover/reel-bezel.png) | discover | 1052 × 974 | 526 × 487 | Preserve aspect |
| TA-027 | [lock-lever-locked](Exports/Discover/lock-lever-locked.png) | discover | 518 × 626 | 259 × 313 | Preserve aspect |
| TA-028 | [lock-lever-open](Exports/Discover/lock-lever-open.png) | discover | 524 × 466 | 262 × 233 | Preserve aspect |
| TA-029 | [match-lamps-on](Exports/Discover/match-lamps-on.png) | discover | 914 × 232 | 457 × 116 | Preserve aspect |
| TA-030 | [match-lamps-off](Exports/Discover/match-lamps-off.png) | discover | 992 × 224 | 496 × 112 | Preserve aspect |
| TA-031 | [timing-track](Exports/Landing/timing-track.png) | landing | 1214 × 304 | 607 × 152 | 9-slice |
| TA-032 | [score-readout](Exports/Landing/score-readout.png) | landing | 1104 × 464 | 552 × 232 | 9-slice |
| TA-035 | [progress-trough](Exports/Landing/progress-trough.png) | landing | 1210 × 170 | 605 × 85 | 9-slice |
| TA-037 | [insertion-rail](Exports/Placement/insertion-rail.png) | placement | 1244 × 442 | 622 × 221 | 9-slice |
| TA-038 | [role-panel-idle](Exports/Placement/role-panel-idle.png) | placement | 742 × 628 | 371 × 314 | 9-slice |
| TA-039 | [role-panel-selected](Exports/Placement/role-panel-selected.png) | placement | 742 × 634 | 371 × 317 | 9-slice |
| TA-040 | [insertion-socket-idle](Exports/Placement/insertion-socket-idle.png) | placement | 456 × 446 | 228 × 223 | Preserve aspect |
| TA-041 | [insertion-socket-selected](Exports/Placement/insertion-socket-selected.png) | placement | 468 × 460 | 234 × 230 | Preserve aspect |
| TA-042 | [focus-corners](Exports/Common/focus-corners.png) | common | 192 × 128 | Native vector | 9-slice |
| TA-043 | [arrow-right](Exports/Common/arrow-right.png) | common | 64 × 36 | Native vector | Preserve aspect |
| TA-044 | [arrow-left](Exports/Common/arrow-left.png) | common | 64 × 36 | Native vector | Preserve aspect |
| TA-045 | [caret-down](Exports/Common/caret-down.png) | common | 48 × 32 | Native vector | Preserve aspect |
| TA-046 | [landing-zone](Exports/Landing/landing-zone.png) | landing | 320 × 192 | Native vector | Preserve aspect |
| TA-047 | [perfect-band](Exports/Landing/perfect-band.png) | landing | 48 × 192 | Native vector | Preserve aspect |
| TA-048 | [score-segment](Exports/Landing/score-segment.png) | landing | 36 × 18 | Native vector | Preserve aspect |
| TA-049 | [insertion-plus](Exports/Placement/insertion-plus.png) | placement | 48 × 48 | Native vector | Preserve aspect |
| TA-050 | [insertion-blocked](Exports/Placement/insertion-blocked.png) | placement | 48 × 48 | Native vector | Preserve aspect |
